# Law Empire: Sierra Leone — Cloudflare Deployment Guide
**Domain:** lawempire.xyz | **Platform:** Cloudflare Pages (free tier)
**Last updated:** August 2026

---

## What You Are Deploying

| File | Purpose |
|---|---|
| `index.html` | Main landing page |
| `play/demo.html` | Full web game demo (204KB) |
| `play/index.html` | Play page wrapper |
| `legal/index.html` | T&C, Privacy, IAP Policy, Community Guidelines |
| `codes/index.html` | Daily gift codes + social links |
| `support/index.html` | FAQ (10 questions) + contact |
| `assets/shared.css` | Brand CSS shared across all pages |
| `_redirects` | Cloudflare Pages URL routing rules |
| `_headers` | Security headers + cache policy |
| `404.html` | Custom "Case Not Found" error page |
| `sitemap.xml` | Google sitemap |
| `robots.txt` | Crawler rules |

**Total site size: 296 KB uncompressed (≈86 KB gzipped)**

---

## METHOD A — Cloudflare Dashboard Direct Upload (Fastest, No GitHub)

### Step 1 — Create Cloudflare Account
1. Go to **dash.cloudflare.com** → Sign up (free)
2. Verify your email

### Step 2 — Create Pages Project
1. In Cloudflare dashboard → **Workers & Pages** → **Create application**
2. Click **Pages** tab → **Upload assets**
3. Project name: `lawempire-xyz`
4. Click **Create project**

### Step 3 — Upload Site Files
1. Unzip `lawempire-website.zip`
2. Drag the entire `lawempire-site/` folder into the upload zone
   (or click "Select from computer" → select all files inside `lawempire-site/`)
3. Click **Deploy site**
4. Wait ~30 seconds — Cloudflare assigns a URL like:
   `https://lawempire-xyz.pages.dev`

### Step 4 — Add Custom Domain (lawempire.xyz)
1. In your Pages project → **Custom domains** tab
2. Click **Set up a custom domain**
3. Enter: `lawempire.xyz` → Click **Continue**
4. **If your domain is already on Cloudflare DNS** (recommended):
   - Cloudflare automatically creates the CNAME record
   - Done in 1–2 minutes
5. **If your domain is NOT on Cloudflare yet:**
   - Go to **Websites** → **Add site** → enter `lawempire.xyz`
   - Choose **Free plan**
   - Cloudflare gives you two nameservers (e.g. `aria.ns.cloudflare.com`)
   - Log into your domain registrar → change nameservers to Cloudflare's
   - Wait 5–30 minutes for DNS propagation
   - Come back and add the custom domain

### Step 5 — Add www redirect
1. In Pages project → **Custom domains** → Add `www.lawempire.xyz`
2. Cloudflare automatically redirects `www` → `lawempire.xyz`

### Step 6 — Enable HTTPS
1. In Cloudflare dashboard → **SSL/TLS** → Set to **Full (strict)**
2. **Edge Certificates** → Enable **Always Use HTTPS**
3. Your site is now live at `https://lawempire.xyz` with a free SSL certificate ✓

---

## METHOD B — GitHub + Auto-Deploy (Recommended for Ongoing Updates)

This method auto-deploys every time you push a change to GitHub.

### Step 1 — Create GitHub Repository
1. Go to **github.com** → **New repository**
2. Name: `lawempire-website` (can be private)
3. Create repository

### Step 2 — Upload Files to GitHub
**Option A — GitHub web interface:**
1. In your new repo → **Add file** → **Upload files**
2. Upload all files from the `lawempire-site/` folder
3. Make sure to include hidden files: `.github/workflows/deploy.yml`
4. Commit to `main` branch

**Option B — Git command line:**
```bash
# Unzip your site files
unzip lawempire-website.zip
cd lawempire-site

# Initialise git and push
git init
git add .
git commit -m "Initial deploy — Law Empire SL website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/lawempire-website.git
git push -u origin main
```

### Step 3 — Connect Cloudflare Pages to GitHub
1. Cloudflare dashboard → **Workers & Pages** → **Create application** → **Pages**
2. Click **Connect to Git** → Authorise GitHub
3. Select repository: `lawempire-website`
4. **Build settings:**
   - Framework preset: **None**
   - Build command: *(leave blank)*
   - Build output directory: `/` (or leave blank)
5. Click **Save and Deploy**

### Step 4 — Add GitHub Secrets (for the Actions workflow)
The `.github/workflows/deploy.yml` file needs two secrets:

1. Get your **Cloudflare Account ID:**
   - Cloudflare dashboard → right sidebar → copy **Account ID**

2. Get your **Cloudflare API Token:**
   - Profile → **API Tokens** → **Create Token**
   - Use template: **Edit Cloudflare Workers**
   - Add permission: **Cloudflare Pages — Edit**
   - Click **Continue to summary** → **Create Token**
   - Copy the token (shown only once)

3. Add to GitHub:
   - Your repo → **Settings** → **Secrets and variables** → **Actions**
   - Add secret: `CLOUDFLARE_API_TOKEN` → paste token
   - Add secret: `CLOUDFLARE_ACCOUNT_ID` → paste account ID

4. Every push to `main` now auto-deploys to Cloudflare Pages ✓

### Step 5 — Add Custom Domain
Same as Method A, Step 4–6 above.

---

## DNS Records — Complete Setup

Once your domain is on Cloudflare, set these DNS records:

```
Type    Name    Content                             Proxy    Purpose
CNAME   @       lawempire-xyz.pages.dev             ✓ ON     Main website
CNAME   www     lawempire-xyz.pages.dev             ✓ ON     www redirect
CNAME   api     lawempire-api.railway.app           ✓ ON     Backend API
MX      @       route1.mx.cloudflare.net  (pri 14)  ✗ OFF   Email routing
MX      @       route2.mx.cloudflare.net  (pri 77)  ✗ OFF   Email routing
TXT     @       v=spf1 include:cloudflare.net ~all   ✗ OFF   Email auth
```

**Proxy (orange cloud) must be ON for @ and www** — this enables Cloudflare CDN,
DDoS protection, and hides your origin IP.

---

## Email Setup — support@lawempire.xyz

Set up **Cloudflare Email Routing** (free) to forward all @lawempire.xyz
addresses to your personal Gmail:

1. Cloudflare dashboard → **Email** → **Email Routing** → **Enable**
2. Add routing rules:
   ```
   support@lawempire.xyz  →  your.personal@gmail.com
   legal@lawempire.xyz    →  your.personal@gmail.com
   privacy@lawempire.xyz  →  your.personal@gmail.com
   bugs@lawempire.xyz     →  your.personal@gmail.com
   hello@lawempire.xyz    →  your.personal@gmail.com
   ```
3. Click the verification link sent to your Gmail

People emailing any @lawempire.xyz address now land in your Gmail. Free forever.

---

## Cloudflare Settings to Configure

After deployment, go through these settings in the Cloudflare dashboard:

### SSL/TLS
- Mode: **Full (strict)**
- Always Use HTTPS: **On**
- HTTP Strict Transport Security (HSTS): **Enable** (max-age: 6 months)
- Minimum TLS Version: **TLS 1.2**

### Speed
- **Auto Minify:** Check CSS, JS, HTML
- **Brotli compression:** On
- **Rocket Loader:** Off (not needed for static HTML)

### Caching
- Caching level: **Standard**
- Browser Cache TTL: **4 hours**
  (assets/ folder has its own 1-year cache via `_headers`)

### Security
- Security Level: **Medium**
- Bot Fight Mode: **On** (free, blocks bad bots)
- Challenge Passage: **30 minutes**

### Page Rules (optional, free tier allows 3)
```
Rule 1: lawempire.xyz/assets/*
  → Cache Level: Cache Everything
  → Edge Cache TTL: 1 month

Rule 2: www.lawempire.xyz/*
  → Forwarding URL (301): https://lawempire.xyz/$1
```

---

## Updating the Website

### Method A (Direct Upload)
1. Make changes to files in `lawempire-site/`
2. Go to Cloudflare Pages → your project → **Create new deployment**
3. Upload the changed files
4. Deploy — live in ~30 seconds

### Method B (GitHub)
1. Edit your files
2. `git add . && git commit -m "Update X" && git push`
3. GitHub Actions auto-deploys — live in ~60 seconds
4. Check deployment status in your repo → **Actions** tab

---

## Testing After Deployment

Open each of these URLs and verify:

```
https://lawempire.xyz              → Landing page loads, logo visible
https://lawempire.xyz/play/        → Game demo loads in iframe
https://lawempire.xyz/codes/       → Gift codes page, copy button works
https://lawempire.xyz/support/     → FAQ accordion opens/closes
https://lawempire.xyz/legal/       → All 4 legal docs visible, sidebar scrolls
https://lawempire.xyz/notapage     → Custom 404 "Case Not Found" page
https://www.lawempire.xyz          → Redirects to lawempire.xyz (no www)
https://lawempire.xyz/sitemap.xml  → XML sitemap loads
https://lawempire.xyz/robots.txt   → Robots file loads
```

### Mobile test (important for SL users)
- Open on Android Chrome — check the hero loads fast
- Navigate to /play/ — game demo should load in browser
- Try the gift code copy button on mobile
- Check FAQ accordion on a small screen

### Speed test
- Run at **pagespeed.web.dev** — target 90+ for mobile
- Run at **gtmetrix.com** — check Time to First Byte (TTFB) < 200ms
  (Cloudflare edge should serve from Lagos or Johannesburg POP for SL users)

---

## Troubleshooting

**Site shows "1001 DNS resolution error"**
→ DNS not propagated yet. Wait 30 minutes and try again.

**CSS not loading (unstyled page)**
→ Check that `assets/shared.css` was uploaded.
→ Check browser console for the exact 404 URL.

**Play demo not loading**
→ Check `play/demo.html` was uploaded (204KB file).
→ The iframe in `play/index.html` points to `/play/demo.html`.

**Custom 404 not showing (Cloudflare default shows instead)**
→ The `404.html` file must be in the root directory, not in a subfolder.
→ In Pages project settings, confirm the root directory is `/`.

**SSL error (ERR_SSL_PROTOCOL_ERROR)**
→ In SSL/TLS settings, change mode from "Flexible" to "Full (strict)".

**Email not arriving at support@lawempire.xyz**
→ Check Email Routing is enabled in Cloudflare dashboard.
→ Verify the destination Gmail address received and clicked the verification link.
→ Check the MX records are set correctly (DNS Only, not Proxied).

**_redirects rules not working**
→ Cloudflare Pages supports `_redirects` natively — no extra setup needed.
→ Check the file is in the root directory and has Unix line endings (LF not CRLF).

---

## Cost Summary

| Service | Cost |
|---|---|
| Cloudflare Pages hosting | **Free** (unlimited bandwidth) |
| Cloudflare DNS + CDN + SSL | **Free** |
| Cloudflare Email Routing | **Free** |
| Domain renewal (lawempire.xyz) | ~$12/year |
| API backend (Railway) | ~$5/month |
| **Total monthly** | **~$5/month** |

---

## Launch Checklist

- [ ] All 13 site files uploaded to Cloudflare Pages
- [ ] `https://lawempire.xyz` resolves and shows landing page
- [ ] `https://www.lawempire.xyz` redirects to non-www
- [ ] SSL padlock visible in browser (HTTPS)
- [ ] `/play/` loads the game demo
- [ ] `/legal/` shows all four legal documents  
- [ ] `/codes/` code copy button works on mobile
- [ ] `/support/` FAQ accordion works
- [ ] Custom 404 page shows for unknown URLs
- [ ] Email Routing active — support@lawempire.xyz forwards to Gmail
- [ ] Google Search Console — submit `https://lawempire.xyz/sitemap.xml`
- [ ] Social media bios updated — link set to `lawempire.xyz`
- [ ] Test on Android Chrome (primary SL browser)
- [ ] PageSpeed score checked — mobile 90+

---

*lawempire.xyz · @lawempire_sl · support@lawempire.xyz*
